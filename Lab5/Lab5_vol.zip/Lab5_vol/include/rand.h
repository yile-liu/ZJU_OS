#pragma once

#include "stdint.h"

#define SEED 13

uint rand();
